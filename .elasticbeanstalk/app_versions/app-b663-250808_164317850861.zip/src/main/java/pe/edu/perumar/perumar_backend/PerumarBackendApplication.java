package pe.edu.perumar.perumar_backend;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PerumarBackendApplication {

	public static void main(String[] args) {
		SpringApplication.run(PerumarBackendApplication.class, args);
	}

}
